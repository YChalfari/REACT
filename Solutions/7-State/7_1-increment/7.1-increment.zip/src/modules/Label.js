import React from "react";

const Label = (props) => {
  return <span className={props.class}>{props.value}</span>;
};
export default Label;
