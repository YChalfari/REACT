const data = ["one", "two", "three", "four", "five"];
export default data;
