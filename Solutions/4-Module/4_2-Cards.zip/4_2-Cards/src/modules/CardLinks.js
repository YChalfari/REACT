import React from "react";

const CardLinks = (props) => {
  return <ul className="card-links">{props.children}</ul>;
};
export default CardLinks;
