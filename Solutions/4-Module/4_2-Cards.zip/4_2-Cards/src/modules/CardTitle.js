import React from "react";

const CardTitle = (props) => {
  return <h3 className="card-title">{props.text}</h3>;
};
export default CardTitle;
