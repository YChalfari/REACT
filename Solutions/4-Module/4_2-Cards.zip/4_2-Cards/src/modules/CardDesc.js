import React from "react";

const CardDesc = (props) => {
  return <p className="card-desc">{props.text}</p>;
};
export default CardDesc;
