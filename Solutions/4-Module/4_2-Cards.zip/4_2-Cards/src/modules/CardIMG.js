import React from "react";

const CardIMG = (props) => {
  return <img src={props.source} className="card-img" alt="random image" />;
};
export default CardIMG;
