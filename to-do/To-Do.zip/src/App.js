import React, { Component } from "react";
import ToDoList from "./components/ToDoList";
import ToDo from "./components/ToDo";
import "./App.css";

class App extends Component {
  render() {
    return (
      <div className="App">
        <ToDoList />
      </div>
    );
  }
}
export default App;
